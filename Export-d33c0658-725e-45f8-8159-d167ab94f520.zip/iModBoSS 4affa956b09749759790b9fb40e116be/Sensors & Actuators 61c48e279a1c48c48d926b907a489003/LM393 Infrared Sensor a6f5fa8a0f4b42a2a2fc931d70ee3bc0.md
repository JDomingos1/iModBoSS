# LM393 Infrared Sensor

Analog: Yes
Digital: Yes
Features: Infrared
Power: 5V

**Author:** *Paulo Sousa*

# Introduction

---

An infrared sensor (IR sensor) is a radiation-sensitive optoelectronic component with a spectral sensitivity in the infrared wavelength range 780 nm … 50 µm. IR sensors are now widely used in motion detectors, which are used in building services to switch on lamps or in alarm systems to detect unwelcome guests. In a defined angle range, the sensor elements detect the heat radiation (infrared radiation) that changes over time and space due to the movement of people. Such infrared sensors only have to meet relatively low requirements and are low-cost mass-produced items. InfraTec does not supply such products, InfraTec develops, produces and sells pyroelectric detectors.

## Objectives

---

In this tutorial, the goal is to introduce and teach anyone how to wire and program this sensor using Arduino IDE software. For this board there is no required library to operate. In this paper, we will discuss the following themes:

- Board aspects
- Wiring
- Code

(This tutorial already presupposes that the reader already has Arduino IDE software or Visual Studio Code (PlatformIO) installed and possesses minimal knowledge.)

# Board aspects

## LM393-IC

---

The LM393 is a dual independent accuracy voltage integrated circuit operated with single or else split supply. These IC’s comprise two independent voltage comparators to operate from an only power supply more than a wide variety of voltages. Working with two supplies is also achievable as long as the variation among the two supply voltages is 2 volts to 36 volts, & VCC is minimum 1.5 volts extra positive than the i/p voltage. The main features of this IC mainly include the following.

![soomthigen.png](LM393%20Hall%20Effect%20Sensor%2079c842a25d0b48a7a838b7d5563ec74d/soomthigen.png)

![LM393%20Hall%20Effect%20Sensor%2079c842a25d0b48a7a838b7d5563ec74d/image6.png](LM393%20Hall%20Effect%20Sensor%2079c842a25d0b48a7a838b7d5563ec74d/image6.png)

- Pin1 (OUTA): Output A
- Pin2 (In A-): Inverting input A
- Pin3 (In A+): Non-inverting input A
- Pin4 (GND): Ground
- Pin5 (INB+): Non-inverting input B
- Pin6 (INB-): Inverting input B
- Pin7 (OUTB): Output B
- Pin8 (VCC): Voltage Supply

The IC LM393 includes two op-amps internally and each op-amp has two inputs as well as one output. These ICs works independently to provide its own output. But, this circuit uses only one operational amplifier and the other op-amp will not be connected. Both the op-amps are necessary only when we use complex circuits for monitoring numerous levels. This circuit checks only one level so it uses one op-amp.

## Infrared LED

---

![LM393%20Infrared%20Sensor%20a6f5fa8a0f4b42a2a2fc931d70ee3bc0/image7.jpeg](LM393%20Infrared%20Sensor%20a6f5fa8a0f4b42a2a2fc931d70ee3bc0/image7.jpeg)

An InfraRed Light Emitting Diode (IRLED) is a special-purpose LED that emits infrared signals in a different wavelength compared to normal LED’s, in this case, infrared. Specifically, it is a semiconductor device that releases infrared rays when exposed to electrical current.

Unlike LEDs that project parts of the visible light spectrum, IRLEDs are not used to provide lighting. They are, instead, most commonly used in various signal transfer systems, such as in remote controls for televisions, night-vision cameras and other devices. An IRLED beams light with data signals to control the device. IRLEDs are also used in security installations, cameras and other kinds of technologies. They are useful because of their low energy consumption and low heat generation.

# Wiring

---

# Code

---