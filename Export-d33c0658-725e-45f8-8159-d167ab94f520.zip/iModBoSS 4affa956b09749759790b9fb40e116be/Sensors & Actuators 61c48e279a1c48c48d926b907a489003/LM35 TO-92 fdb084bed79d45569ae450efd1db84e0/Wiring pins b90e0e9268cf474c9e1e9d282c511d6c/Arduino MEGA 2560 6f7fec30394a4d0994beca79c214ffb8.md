# Arduino MEGA 2560

: 5V
 1: GND
 2: A0