# LM393 Hall Effect Sensor

Analog: Yes
Digital: Yes
Features: Hall Effect
Power: 5V

**Author:** *Paulo Sousa*

# Introduction

---

A Hall effect sensor is a type of sensor which detects the presence and magnitude of a magnetic field using the Hall effect. **The output voltage of a Hall sensor is directly proportional to the strength of the field.**
Hall sensors are used for proximity sensing, positioning, speed detection, and current sensing applications. Frequently, a Hall sensor is combined with threshold detection to act as a binary switch. Commonly seen in industrial applications such as the pictured pneumatic cylinder, they are also used in consumer equipment; for example, some computer printers use them to detect missing paper and open covers. Some 3D printers use them to measure filament thickness.
Hall sensors are commonly used to time the speed of wheels and shafts, such as for internal combustion engine ignition timing, tachometers and anti-lock braking systems. They are used in brushless DC electric motors to detect the position of the permanent magnet. In the pictured wheel with two equally spaced magnets, the voltage from the sensor peaks twice for each revolution. This arrangement is commonly used to regulate the speed of disk drives.

## Objectives

---

In this tutorial, the goal is to introduce and teach anyone how to wire and program this sensor using Arduino IDE software. For this board there is no required library to operate. In this paper, we will discuss the following themes:

- Board aspects
- Wiring
- Code

(This tutorial already presupposes that the reader already has Arduino IDE software or Visual Studio Code (PlatformIO) installed and possesses minimal knowledge.)

# Board aspects

## LM393-IC

---

The LM393 is a dual independent accuracy voltage integrated circuit operated with single or else split supply. These IC’s comprise two independent voltage comparators to operate from an only power supply more than a wide variety of voltages. Working with two supplies is also achievable as long as the variation among the two supply voltages is 2 volts to 36 volts, & VCC is minimum 1.5 volts extra positive than the i/p voltage. The main features of this IC mainly include the following.

![soomthigen.png](LM393%20Hall%20Effect%20Sensor%2079c842a25d0b48a7a838b7d5563ec74d/soomthigen.png)

![LM393%20Hall%20Effect%20Sensor%2079c842a25d0b48a7a838b7d5563ec74d/image6.png](LM393%20Hall%20Effect%20Sensor%2079c842a25d0b48a7a838b7d5563ec74d/image6.png)

<aside>
💡 Pin1 (OUTA): Output A
Pin2 (In A-): Inverting input A
Pin3 (In A+): Non-inverting input A
Pin4 (GND): Ground
Pin5 (INB+): Non-inverting input B
Pin6 (INB-): Inverting input B
Pin7 (OUTB): Output B
Pin8 (VCC): Voltage Supply

</aside>

The IC LM393 includes two op-amps internally and each op-amp has two inputs as well as one output. These ICs works independently to provide its own output. But, this circuit uses only one operational amplifier and the other op-amp will not be connected. Both the op-amps are necessary only when we use complex circuits for monitoring numerous levels. This circuit checks only one level so it uses one op-amp.

## 3144E

---

The 314XX Hall-effect switches are monolithic integrated circuits with tighter magnetic specifications, designed to operate continuously over extended temperatures to +150°C, and are more stable with both temperature and supply voltage changes. The unipolar switching characteristic makes these devices ideal for use with a simple bar or rod magnet. The four basic devices (3141, 3142, 3143, and 3144) are identical except for magnetic switch points.
Each device includes a voltage regulator for operation with supply voltages of 4.5 to 24 volts, reverse battery protection diode, quadratic Hall-voltage generator, temperature compensation circuitry, small signal amplifier, Schmitt trigger, and an open-collector output to sink up to 25 mA. With suitable output pull up, they can be used with bipolar or CMOS logic circuits.

# Wiring

![Untitled](LM393%20Hall%20Effect%20Sensor%2079c842a25d0b48a7a838b7d5563ec74d/Untitled.png)

![Untitled Sketch 2_bb.png](LM393%20Hall%20Effect%20Sensor%2079c842a25d0b48a7a838b7d5563ec74d/Untitled_Sketch_2_bb.png)

[Wiring pins ](LM393%20Hall%20Effect%20Sensor%2079c842a25d0b48a7a838b7d5563ec74d/Wiring%20pins%202b01eba2256f4d4aa7153929d614dd3e.csv)