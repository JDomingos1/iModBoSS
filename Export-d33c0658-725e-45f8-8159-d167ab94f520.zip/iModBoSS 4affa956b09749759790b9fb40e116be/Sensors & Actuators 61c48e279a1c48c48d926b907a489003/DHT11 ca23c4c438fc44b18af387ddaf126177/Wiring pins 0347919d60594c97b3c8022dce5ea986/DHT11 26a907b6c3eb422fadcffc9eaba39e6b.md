# DHT11

: VCC
 1: GND
 2: Not connected
 3: Signal