# Arduino MEGA 2560

: 3.3V
 1: GND
 2: 21 (SCL)
 3: 20 (SDA)