# Arduino MEGA 2560

: 3.3V
 2: 49 (CS)
 3: 50 (MISO)
 4: 51 (MOSI)
 5: 52 (SCK)
POWER: GND