# Digilent Basys 3

Dimensions [L x W]: 81.28 x 127 mm

[Basys 3](https://digilent.com/reference/programmable-logic/basys-3/start)

The Basys 3 board is a complete, ready-to-use digital circuit development platform based on the latest Artix-7 Field Programmable Gate Array (FPGA) from Xilinx. With its high-capacity FPGA (Xilinx part number  [XC7A35T-1CPG236C](https://docs.xilinx.com/v/u/en-US/ds181_Artix_7_Data_Sheet)), low overall cost, and collection of USB, VGA, and other ports, the Basys3 can host designs ranging from introductory combinational circuits to complex sequential circuits like embedded processors and controllers. It includes enough switches, LEDs and other I/O devices to allow a large number designs to be completed without the need for any additional hardware, and enough uncommitted FPGA I/O pins to allow designs to be expanded using Digilent Pmods or other custom boards and circuits.

[108638983.webp](Digilent%20Basys%203%2048d3f684fced4a1aac66dfca74df3eea/108638983.webp)