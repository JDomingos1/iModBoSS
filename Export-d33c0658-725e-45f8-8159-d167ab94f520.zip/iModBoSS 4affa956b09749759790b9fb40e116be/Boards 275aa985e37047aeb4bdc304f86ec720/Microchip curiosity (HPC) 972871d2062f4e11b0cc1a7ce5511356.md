# Microchip curiosity (HPC)

Dimensions [L x W]: 198.88 x 134.87 mm

[](https://www.microchip.com/en-us/development-tool/dm164136)

Supports 28 or 40-pin 8-bit PIC Microcontrollers with low voltage programming capability.
Integrated Programmer/Debugger with USB Interface Integrates seamlessly with MPLAB X IDE and Code Configurator Various user interface options - analog potentiometer, and physical switches.

![microchip.png](Microchip%20curiosity%20(HPC)%20972871d2062f4e11b0cc1a7ce5511356/microchip.png)