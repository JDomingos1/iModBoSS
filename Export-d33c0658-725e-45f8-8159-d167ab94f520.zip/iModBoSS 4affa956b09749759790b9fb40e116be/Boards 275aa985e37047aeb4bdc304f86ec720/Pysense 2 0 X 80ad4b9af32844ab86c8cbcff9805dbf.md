# Pysense 2.0 X

[Pysense 2.0 X](https://pycom.io/product/pysense-2-0-x/)

![Untitled](Pysense%202%200%20X%2080ad4b9af32844ab86c8cbcff9805dbf/Untitled.png)