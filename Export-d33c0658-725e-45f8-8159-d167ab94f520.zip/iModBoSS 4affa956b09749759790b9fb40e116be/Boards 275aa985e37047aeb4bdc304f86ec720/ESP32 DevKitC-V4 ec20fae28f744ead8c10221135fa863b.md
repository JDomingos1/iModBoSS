# ESP32 DevKitC-V4

Dimensions [L x W]: 54.4 x 48.2 mm

[ESP32-DevKitC V4 Getting Started Guide - ESP32 - - ESP-IDF Programming Guide latest documentation](https://docs.espressif.com/projects/esp-idf/en/latest/esp32/hw-reference/esp32/get-started-devkitc.html)

Espressif Systems ESP32-DevKitC Development Boards are small space saving boards designed to support various ESP32 modules. Most of the I/O pins are broken out to the pin headers on both sides for easy interfacing. Connect these pins to peripherals as needed. Standard headers also make development easy and convenient when using a breadboard.

![esp32.png](ESP32%20DevKitC-V4%20ec20fae28f744ead8c10221135fa863b/esp32.png)

## Pinout

![Untitled](ESP32%20DevKitC-V4%20ec20fae28f744ead8c10221135fa863b/Untitled.png)