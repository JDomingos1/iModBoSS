# Pycom Expansion Board 3.0

Dimensions [L x W]: 110 x 49.5 mm

[Expansion Board 3.0 - Pycom](https://pycom.io/product/expansion-board-3-0/)

The Pycom Expansion Board 3.0 allows you the means to create and connect new IoT projects with your WiPy 2.0, WiPy 3.0, LoPy, LoPy4, SiPy, FiPy, and GPy everywhere! With dozens of ready to use templates and libraries, developing a new IoT solution is now easier and faster.
Each Expansion Board can be powered via micro USB or LiPo JST for 100mA or 450mA batteries and features a custom PIC USB to serial converter with an automatic bootloader mode to program your Pycom development board. There is also an on-board microSD card slot to increase the storage capacity of your desired board.

![pycom_2.png](Pycom%20Expansion%20Board%203%200%208235118242a24e39a731cb44cc7bf6d5/pycom_2.png)