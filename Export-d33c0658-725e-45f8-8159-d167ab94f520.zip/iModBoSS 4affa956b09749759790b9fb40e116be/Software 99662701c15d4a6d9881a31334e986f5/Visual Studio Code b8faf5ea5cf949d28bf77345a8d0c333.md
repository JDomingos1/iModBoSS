# Visual Studio Code

**Authors:** *João Domingos, Paulo Sousa, Pedro Ferreira*

---

INSERT TUTORIAL

[Platform Io](Visual%20Studio%20Code%20b8faf5ea5cf949d28bf77345a8d0c333/Platform%20Io%206054d81e2a3b42db8a8a85062154280c.md)